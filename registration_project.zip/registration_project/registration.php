<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php'; // PHPMailer
require_once('tcpdf/tcpdf.php'); // TCPDF

$conn = new mysqli("localhost", "root", "", "user_registration");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST['first_name'];
    $middleName = $_POST['middle_name'];
    $lastName = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("INSERT INTO users (first_name, middle_name, last_name, email, password) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $firstName, $middleName, $lastName, $email, $password);
    $stmt->execute();
    $stmt->close();

    $pdf = new TCPDF();
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 12);

    $content = <<<EOD
User Registration Details:

First Name: $firstName
Middle Name: $middleName
Last Name: $lastName
Email: $email
Password: $password
EOD;

    $pdf->Write(0, $content);
    $pdfPath = __DIR__ . "/user_details_$email.pdf";
    $pdf->Output($pdfPath, 'F');

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = '	smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'durganandpatna6@gmail.com';
        $mail->Password = 'dcjitbqqrnezynjz'; // NOT your real Gmail password

        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('durganandptna6@gmail.com', 'Registration System');
        $mail->addAddress($email, $firstName);
        $mail->Subject = 'Your Registration Details';
        $mail->Body = "Hi $firstName,\n\nThank you for registering. Your details are attached as a PDF.";
        $mail->addAttachment($pdfPath);

        $mail->send();
        echo "Registration complete! PDF sent to $email";
    } catch (Exception $e) {
        echo "Email could not be sent. Error: {$mail->ErrorInfo}";
    }

    unlink($pdfPath);
}
?>